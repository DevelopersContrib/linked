
<? include_once 'header.php'; ?>



<div id="container2">
<div id="middlebox">
<div id="content2">
<h2> <?=$domain?> Services</h2>
<p>We're in the business of domain life cycle development, management and monetization of domain names. For over 15 years we have been making domains a valuable technology asset that leverages the latest in real-time, interactive web-based communications and technology to rapidly build business within descriptive domain names. </p>

    Venture Creation and Financing<br />
    Applications Development and Management<br />
    WebManagement<br />
    Business Management<br />
    Marketing Services<br />
    Product/Service Branding<br />
    E-Commerce<br />
    Design Services <br />
    Consultation<br />
    Domain Acquisition and Divestments<br />
<p>
There is absolutely no obligation when filling out the form, it is for informational exchange purposes only. So please take a few moments to <a href="/services">fill out the form</a> and we will get back with you within 2 business days.
</p>


<iframe style="width: 400px; background-color: lightGrey; height: 525px;" src="http://domaindirectory.com/servicepage/contactus2_form.php?domain=<?=$domain?>"></iframe>

</div><!-- content2 -->
</div>
</div>


<? include_once 'footer.php';?>