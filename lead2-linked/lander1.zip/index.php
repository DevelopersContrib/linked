<? include 'header.php'; ?>
<meta name="linked" content="458431187548-hh7e32mu2iqs960ram2b6m0vt6pmoe9c.apps.googleusercontent.com"></meta>
<script src="https://cdnjs.cloudflare.com/ajax/libs/masonry/3.3.1/masonry.pkgd.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="//platform.linkedin.com/in.js"> 
			api_key: 78c8mstf5k8lbd
			authorize: true
		</script>
<!-- <script type="text/javascript" src="/js/linkedin.js"></script> -->
<script type="text/javascript">
	
	// for linkedin  . 

	function liAuth(){
	   IN.User.authorize(function(){
		   getProfileData();
	   });
	}

    // Handle the successful return from the API call
    function onSuccess(data) {
        console.log(data);
    }

    // Handle an error response from the API call
    function onError(error) {
        console.log(error);
    }

    // Use the API call wrapper to request the member's basic profile data
    function getProfileData() {
        //IN.API.Raw("/people/~").result(onSuccess).error(onError);
		IN.API.Profile("me").fields("first-name", "last-name", "email-address","public-profile-url").result(function (data) {
			console.log(data);
			// document.getElementById("email").value = data.values[0].emailAddress;
			// document.getElementById("firstname").value = data.values[0].firstName;
			// document.getElementById("lastname").value = data.values[0].lastName;
			//document.getElementById('btn-linkedin').style.display = 'none';
			
			var emailAddress = data.values[0].emailAddress;
			var user_ip = $('#user_ip').val();
			var domain = $('#domain').val(); 

			var formdata = {
				emailAddress:emailAddress,
				user_ip:user_ip,
				domain:domain
			}
			console.log(formdata);

			//DOMAINDI LEADS		

			  jQuery.ajax({
  			        type: "post",url: "http://www.contrib.com/forms/saveleads",
  			        data: {'email':emailAddress, 'domain':domain,'user_ip':user_ip},
  				    success: function(res){
					console.log(res.success);
					$('#error_message_form').addClass('text-warning');
					$('#error_message_form').html("Processing, please wait..");
					console.log(res);
					  
					$("#loading").hide();
					
					if(res.success=='success'){
						// $("#signupform").hide();	
						// $('#response_wait').show();
						// $("#pagesubmit").slideDown('normal');
						 window.location.href = 'thanks';
						// $('#pemail').val(email);
						// $('#response').css('display','block');
						// $('#error_message_form').hide();

				}else{
						console.log("FALSE 2");
						$('#error_message_form').removeClass('text-warning');
						$('#error_message_form').addClass('text-danger');
						$('#error_message_form').html(res.success+'<br><br>');
				}
                  
                }});	
								
				// SALESFORCE LEAD
				$.post("http://www.manage.vnoc.com/salesforce/addlead",
				{
					 'firstName':name,
					 'lastName':name,
					 'title':'',
					 'email':email,
					 'phone':'',
					 'street':'',
					 'city':'',
					 'country':'',
					 'state':'',
					 'zip':'',
					 'domain':domain,
					 'form_type':'Contrib Lead Template'
					 
				},function(data2){
						console.log(data2);
					}
				);	

		}).error(function (data) {
			console.log(data);
		});
    }

   	// for facebook retrieve 
    
  // Load the SDK asynchronously
  (function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "//connect.facebook.net/en_US/sdk.js";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));
		

   function statusChangeCallback(response) {
    console.log('statusChangeCallback');
    console.log(response);
    // The response object is returned with a status field that lets the
    // app know the current login status of the person.
    // Full docs on the response object can be found in the documentation
    // for FB.getLoginStatus().
    if (response.status === 'connected') {
      // Logged into your app and Facebook.
      testAPI();
    } else if (response.status === 'not_authorized') {
      // The person is logged into Facebook, but not your app.
      // document.getElementById('status').innerHTML = 'Please log ' +
      //   'into this app.';
      console.log("please log into this app");
    } else {
      // The person is not logged into Facebook, so we're not sure if
      // they are logged into this app or not.
      // document.getElementById('status').innerHTML = 'Please log ' +
      //   'into Facebook.';
        console.log("Please Login to Facebook");
    }
  }

  // This function is called when someone finishes with the Login
  // Button.  See the onlogin handler attached to it in the sample
  // code below.


  window.fbAsyncInit = function() {
  FB.init({
    appId      : '296067360739698',
    cookie     : true,  // enable cookies to allow the server to access 
                        // the session
    xfbml      : true,  // parse social plugins on this page
    version    : 'v2.6' // use graph api version 2.5
  });

  // Now that we've initialized the JavaScript SDK, we call 
  // FB.getLoginStatus().  This function gets the state of the
  // person visiting this page and can return one of three states to
  // the callback you provide.  They can be:
  //
  // 1. Logged into your app ('connected')
  // 2. Logged into Facebook, but not your app ('not_authorized')
  // 3. Not logged into Facebook and can't tell if they are logged into
  //    your app or not.
  //
  // These three cases are handled in the callback function.

  // FB.getLoginStatus(function(response) {
  //   // statusChangeCallback(response);
  //   	if (response.status === 'connected') {
  //   			testAPI();
  //   	}else{
		// 	initializeFblogin();
  //   	}
  // });

  };
  function checkLoginState() {
    FB.getLoginStatus(function(response) {
      // statusChangeCallback(response);
      			if (response.status === 'connected') 
      			{
    				testAPI();
			    }
			    else
			    {
					initializeFblogin();
			    }
    });
  }
  // Here we run a very simple test of the Graph API after login is
  // successful.  See statusChangeCallback() for when this call is made.
  function testAPI() {
    console.log('Welcome!  Fetching your information.... ');
    FB.api('/me?fields=name,email', function(response) {
      console.log('Successful login for: ' + response.name + " " + response.email);
      var myemail = response.email;

      console.log(myemail);

      		var emailAddress = myemail;
  	 		var user_ip = $('#user_ip').val();
			var domain = $('#domain').val(); 

			var formdata = {
				user_ip:user_ip,
				domain:domain,
				emailAddress:emailAddress
			}

			console.log(formdata);

			jQuery.ajax({
  			        type: "post",url: "http://www.contrib.com/forms/saveleads",
  			        data: {'email':emailAddress, 'domain':domain,'user_ip':user_ip},
  				    success: function(res){
					console.log(res.success);
					$('#error_message_form').addClass('text-warning');
					$('#error_message_form').html("Processing, please wait..");
					console.log(res);
					  
					$("#loading").hide();
					
					if(res.success=='success'){
						// $("#signupform").hide();	
						// $('#response_wait').show();
						// $("#pagesubmit").slideDown('normal');
						 window.location.href = 'thanks';
						// $('#pemail').val(email);
						// $('#response').css('display','block');
						// $('#error_message_form').hide();
					}else{
							console.log("FALSE 2");
							$('#error_message_form').removeClass('text-warning');
							$('#error_message_form').addClass('text-danger');
							$('#error_message_form').html(res.success+'<br><br>');
					}
                }});	
								
				// SALESFORCE LEAD
				$.post("http://www.manage.vnoc.com/salesforce/addlead",
				{
					 'firstName':name,
					 'lastName':name,
					 'title':'',
					 'email':email,
					 'phone':'',
					 'street':'',
					 'city':'',
					 'country':'',
					 'state':'',
					 'zip':'',
					 'domain':domain,
					 'form_type':'Contrib Lead Template'
					 
				},function(data2){
						console.log(data2);
					}
				);	


    });
   
  }
  function initializeFblogin(){
   		FB.login(function(response) {
           testAPI();
         }, {scope: 'public_profile,email'});
  	 }

  	 // function ajaxsave(){



  	 // 		  jQuery.ajax({
  		// 	        type: "post",url: "http://www.contrib.com/forms/saveleads",
  		// 	        data: {'email':emailAddress, 'domain':domain,'user_ip':user_ip},
  		// 		    success: function(res){
				// 	console.log(res.success);
				// 	$('#error_message_form').addClass('text-warning');
				// 	$('#error_message_form').html("Processing, please wait..");
				// 	console.log(res);
					  
				// 	$("#loading").hide();
					
				// 	if(res.success=='success'){
				// 		// $("#signupform").hide();	
				// 		// $('#response_wait').show();
				// 		// $("#pagesubmit").slideDown('normal');
				// 		 window.location.href = 'thanks';
				// 		// $('#pemail').val(email);
				// 		// $('#response').css('display','block');
				// 		// $('#error_message_form').hide();

				// }else{
				// 		console.log("FALSE 2");
				// 		$('#error_message_form').removeClass('text-warning');
				// 		$('#error_message_form').addClass('text-danger');
				// 		$('#error_message_form').html(res.success+'<br><br>');
				// }
                  
    //             }});	
								
				// // SALESFORCE LEAD
				// $.post("http://www.manage.vnoc.com/salesforce/addlead",
				// {
				// 	 'firstName':name,
				// 	 'lastName':name,
				// 	 'title':'',
				// 	 'email':email,
				// 	 'phone':'',
				// 	 'street':'',
				// 	 'city':'',
				// 	 'country':'',
				// 	 'state':'',
				// 	 'zip':'',
				// 	 'domain':domain,
				// 	 'form_type':'Contrib Lead Template'
					 
				// },function(data2){
				// 		console.log(data2);
				// 	}
				// );	
  	 // }

	// end of the facebook singup

</script>
<script type="text/javascript">
		$(document).ready(function(){
				var owl = $('.container-feature');
				owl.owlCarousel({
					items:4,
					loop:true,
					margin:10,
					autoplay:true,
					autoplayTimeout:1000,
					autoplayHoverPause:true,
					responsiveClass:true,
				    responsive:{
				        0:{
				            items:1,
				            nav:true
				        },
				        480:{
				            items:2,
				            nav:false
				        },
				        768:{
				            items:3,
				            nav:true,
				            loop:false
				        }
				    }
				});   

		});

</script>

<!-- start with google plus sign up -->
	
	<script type="text/javascript">

		var auth2 = {};
		var helper = (function() {
		  return {
		    /**
		     * Hides the sign in button and starts the post-authorization operations.
		     *
		     * @param {Object} authResult An Object which contains the access token and
		     *   other authentication information.
		     */
		    onSignInCallback: function(authResult) {
		      $('#authResult').html('Auth Result:<br/>');
		      for (var field in authResult) {
		        $('#authResult').append(' ' + field + ': ' +
		            authResult[field] + '<br/>');
		      }
		      if (authResult.isSignedIn.get()) {
		        $('#authOps').show('slow');
		        $('#gConnect').hide();
		        helper.profile();
		        
		      } else {
		          if (authResult['error'] || authResult.currentUser.get().getAuthResponse() == null) {
		            // There was an error, which means the user is not signed in.
		            // As an example, you can handle by writing to the console:
		            console.log('There was an error: ' + authResult['error']);
		          }
		          $('#authResult').append('Logged out');
		          $('#authOps').hide('slow');
		          $('#gConnect').show();
		      }

		      console.log('authResult', authResult);
		    },

		    /**
		     * Calls the OAuth2 endpoint to disconnect the app for the user.
		     */
		    disconnect: function() {
		      // Revoke the access token.
		      auth2.disconnect();
		    },
		    /**
		     * Gets and renders the currently signed in user's profile data.
		     */
		    profile: function(){
		      gapi.client.plus.people.get({
		        'userId': 'me'
		      }).then(function(res) {
		        var profile = res.result;
		        console.log(profile);
		        $('#profile').empty();
		        $('#profile').append(
		            $('<p><img src=\"' + profile.image.url + '\"></p>'));
		        $('#profile').append(
		            $('<p>Hello ' + profile.displayName + '!<br />Tagline: ' +
		            profile.tagline + '<br />About: ' + profile.aboutMe + '</p>'));
		        if (profile.emails) {
		          $('#profile').append('<br/>Emails: ');
		          for (var i=0; i < profile.emails.length; i++){
		            $('#profile').append(profile.emails[i].value).append(' ');

		              var email = $('#googleemail').val(profile.emails[i].value);
		              var user_ip = $('#user_ip').val();
				      var domain = $('#domain').val(); 	

				        jQuery.ajax({
		  			        type: "post",url: "http://www.contrib.com/forms/saveleads",
		  			        data: {'email':email, 'domain':domain,'user_ip':user_ip},
		  				    success: function(res){
							console.log(res.success);
							$('#error_message_form').addClass('text-warning');
							$('#error_message_form').html("Processing, please wait..");
							console.log(res);
							  
							$("#loading").hide();
							
							if(res.success=='success'){
								// $("#signupform").hide();	
								// $('#response_wait').show();
								// $("#pagesubmit").slideDown('normal');
								 window.location.href = 'thanks';
								// $('#pemail').val(email);
								// $('#response').css('display','block');
								// $('#error_message_form').hide();

						}else{
								console.log("FALSE 2");
								$('#error_message_form').removeClass('text-warning');
								$('#error_message_form').addClass('text-danger');
								$('#error_message_form').html(res.success+'<br><br>');
						}
		                  
		                }});	
										
						// SALESFORCE LEAD
						$.post("http://www.manage.vnoc.com/salesforce/addlead",
						{
							 'firstName':name,
							 'lastName':name,
							 'title':'',
							 'email':email,
							 'phone':'',
							 'street':'',
							 'city':'',
							 'country':'',
							 'state':'',
							 'zip':'',
							 'domain':domain,
							 'form_type':'Contrib Lead Template'
							 
						},function(data2){
								console.log(data2);
							}
						);	

		               
		          }
		          $('#profile').append('<br/>');
		        }
		        if (profile.cover && profile.coverPhoto) {
		          $('#profile').append(
		              $('<p><img src=\"' + profile.cover.coverPhoto.url + '\"></p>'));
		        }
		      }, function(err) {
		        var error = err.result;
		        $('#profile').empty();
		        $('#profile').append(error.message);
		      });
		    }
		  };
		})();

		/**
		 * jQuery initialization
		 */
		// $(document).ready(function() {
		//   $('#disconnect').click(helper.disconnect);
		//   $('#loaderror').hide();
		//   if ($('meta')[0].content == '458431187548-hh7e32mu2iqs960ram2b6m0vt6pmoe9c.apps.googleusercontent.com') {
		//     alert('This sample requires your OAuth credentials (client ID) ' +
		//         'from the Google APIs console:\n' +
		//         '    https://code.google.com/apis/console/#:access\n\n' +
		//         'Find and replace CLIENT ID   with your client ID.'
		//     );
		//   }
		// });

		/**
		 * Handler for when the sign-in state changes.
		 *
		 * @param {boolean} isSignedIn The new signed in state.
		 */
		var updateSignIn = function() {
		  console.log('update sign in state');
		  if (auth2.isSignedIn.get()) {
		    console.log('signed in');
		    helper.onSignInCallback(gapi.auth2.getAuthInstance());
		  }else{
		    console.log('signed out');
		    helper.onSignInCallback(gapi.auth2.getAuthInstance());
		  }
		}
		/**
		 * This method sets up the sign-in listener after the client library loads.
		 */
		function startApp() {
		  gapi.load('auth2', function() {
		    gapi.client.load('plus','v1').then(function() {
		      gapi.signin2.render('googlelogin', {
		          scope: 'https://www.googleapis.com/auth/plus.login',
		          fetch_basic_profile: true });
		      gapi.auth2.init({
		           client_id: '458431187548-hh7e32mu2iqs960ram2b6m0vt6pmoe9c.apps.googleusercontent.com',
		           cookiepolicy: 'single_host_origin',
		           fetch_basic_profile: true,
		           scope:'https://www.googleapis.com/auth/plus.login'}).then(
		            function (){
		              console.log('init');
		              auth2 = gapi.auth2.getAuthInstance();
		              auth2.isSignedIn.listen(updateSignIn);
		              auth2.then(updateSignIn);
		            });
		    });
		  });
		}



		</script>
		<script src="https://apis.google.com/js/client:platform.js?onload=startApp"></script>

<!-- end with google plus sign up -->
<link rel="stylesheet" href="css/owl.carousel.css">

<style type="text/css">
	.wrap-marketplace-box-item {
		background-color: #fff;
		border-radius: 2px;
		border-top: 1px solid #d9d9d9;
		box-shadow: 0 1px 0 1px #d9d9d9;
		color: #000;
		display: block;
		margin-bottom: 25px;
		padding: 15px;
		text-align: center;
		text-shadow: none;
		word-wrap: break-word;
	}
	.wmbi-img-logo {
		display: block;
		margin-bottom: 15px;
	}
	.wmbi-img-logo img {
		display: inline-block;
		max-height: 60px;
	}
	.btn-group-lg > .btn, .btn-lg {
		border-radius: 6px;
		font-size: 18px;
		line-height: 1.33333;
		padding: 10px 16px;
	}

	.fb {
		background-color: #3A589B;
	}
	.twitter {
		background-color: #3A589B;
	}
	.linkedin {
		background-color: #1D87BD;
		margin-left: 35px;
	}
	.google {
		background-color: #D6492F;
	}
</style>



<script>
	jQuery(document).ready(function(){
        jQuery(".item-container-rp").masonry({
            columnWidth: '.col-md-4',
            transitionDuration: '0.4s',
            itemSelector: '.item-selector'
        });
    });
</script>

		<div class="row">
				<div class="col-lg-12">
					<div class="wrap-padtop-v1 clearfix">
						<div class="row">
							<div class="col-lg-6">								
								<!-- tabs -->
								<div class="tabbable newtemptab">
								  <ul class="nav nav-tabs">
									<li class="active"><a href="#one" data-toggle="tab"><i class="fa fa-cog"></i></a></li>
									<li><a href="#two" data-toggle="tab"><i class="fa fa-bar-chart"></i>&nbsp;Latest Contribution</a></li>
									<li><a href="#twee" data-toggle="tab"><i class="fa fa-comments"></i>&nbsp;Discussions</a></li>
								  </ul>
								  <div class="tab-content">
									<div class="tab-pane active" id="one">
										<div class="exerpt-slide">
											<p>
												<?
													if(str_replace(' ','',$description)!='') echo '<div id="content"><p id="makea" style="color: whitesmoke;text-shadow: 1px 1px 5px black;">'.stripslashes($description).'</p>';
												?> 
											</p>
											</div>								
										</div>
									</div>
									<div class="tab-pane" id="two">
										<div class="condis">
										<script src="http://tools.contrib.com/cwidget?d=<?echo $domain?>&p=ur&c=lc"></script>
										</div>
									</div>
									<div class="tab-pane" id="twee">
										<div class="condis">
										<script type="text/javascript" src="http://tools.contrib.com/cwidget/forum?f=all&l=10"></script>
										</div>
									</div>
								   </div>
								</div>
								<!-- /tabs -->
							</div>
							<div class="col-lg-6">
								<div class="arrw-rela"><div class="arrw-point-white"></div></div>
								<div class="modal-content form">
									<div class="modal-header">
										<h4 class="modal-title text-black">
											Learn more about Joining our Partner Network.
										</h4>
									</div>
									<div class="modal-body">
										<div class="text-center" id="socials_container"></div>
										<div class="form-group">
											
											<form  id="signupform" action="">
												<div class="input-group input-group-lg">
													<input type="text" id="email" class="form-control" placeholder="Your email...">
													<span class="input-group-btn">
														<button type="submit" class="btn btn-danger">
															<i class="fa fa-edit"></i>
															Sign up now!
														</button>
													</span>
												</div>
												<input type="hidden" id="refid" value="0">
												<input type="hidden" id="domain" value="<?php echo $domain?>">
												<input type="hidden" id="user_ip" value="<?php echo $_SERVER['REMOTE_ADDR']?>">
											</form><!-- /input-group -->
											
										</div>
										<div class="form-group">
											<a href="javascript:;" onclick="liAuth()" class="btn btn-info linkedin">
												Sign in 
												<i class="fa fa-linkedin-square"></i>
												LinkedIn
											</a>
											<a href="javascript:;" onclick="checkLoginState()" class="btn btn-info fb">
												Sign in
												<i class="fa fa-facebook-square"></i>
												Facebook
											</a>
											<a href="javascript:;" id="googlelogin" class="btn btn-info google">
												Sign in
												<i class="fa fa-google-plus-square"></i>
												Google
											</a>
											<input type="hidden" id="googleemail" value="">

										<!-- <fb:login-button scope="public_profile,email" onlogin="checkLoginState();">
										</fb:login-button>
										 -->

										</div>
												<div id="error_message_form">&nbsp;</div>
														<div class="pages hidden" id="pagesubmit">
															<div id="response_wait"><div class="span12" style="width:100%;text-align:center;margin:20px 0 35px 0;color:white;min-height:20px;font-size:18px;" id="loading">Processing . . . Please wait . . .</div></div>
																	 <div class="row-fluid" id="response" style="color: rgb(12, 179, 32);display:none">
																		
																		<div class="span12 text-center"><h3>Thanks, your spot is reserved!</h3> Share <?php echo ucfirst($domain)?> with you friends to move up in line and reserve your username.
																				<br><br>
																				<?if($additional_html != ""):?>
																					<?echo base64_decode($additional_html)?>
																				<?endif;?>
																				
																					<form target="_blank" action="http://www.contrib.com/signup/follow/<?php echo ucfirst($domain)?>" method="post">
																					<input type="hidden" id="pemail" name="email" value=""/>
																				<button class="btn btn-warning">Continue to Follow <?php echo ucfirst($domain)?> Brand</button></form>
																		</div>
																		
																	 
																	 </div><!-- response -->
																		<div id="description">
																						<h3 id="header_text"></h3>
																						<p id="paragraph_text"></p>
																						<p style="color:#000">To share with your friends, click &ldquo;Share&rdquo; and &ldquo;Tweet&rdquo;:</p>
																						<a href="http://twitter.com/share" class="twitter-share-button" data-count="none">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script>
																						<br><br>
																						<p> <iframe src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.socialholdings.com%2F&amp;layout=standard&amp;show_faces=true&amp;width=450&amp;action=like&amp;font&amp;colorscheme=light&amp;height=80" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:80px;" allowTransparency="true"></iframe>
																						</p>
																						<div id="sharebuttons"><span id="facebook" style="margin:0 0 10px 60px"></span><span id="twitter"></span></div>
																					</div>
																					<!--<p class="clear" style="text-align: left;">Or copy and paste the following link to share wherever you want!</p>
																								<input id="shareurl" type="text" value="" />
																						-->
																					 <!-- <a class="cs_import">Email To Friends</a>-->

																				</div>
										
									</div>
									<div class="modal-footer">
										<div class="text-left form-group">
											<a href="/privacy">Privacy Policy</a> 
											<span class="text-black">
												|
											</span> 
											<a href="/terms">Terms and Condition</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
		</div>
		<!-- verticals -->
		<?php if (count($related_domains)>0):?>
		<?php $vertical = str_replace('-',' ',ucfirst($related_domains[0]['slug'])) ?>
		<div class="row verb">
			<div class="col-md-8 col-md-offset-2">
				<h2><i class="fa fa-globe"></i>&nbsp; Other Brands On <?php echo $vertical?> Vertical</h2>
				<div class="vertical-list">
					<ul class="list-unstyled">
						<?php foreach ($related_domains as $key=>$val):?>
							<li class="col-md-4 odd"><a href="http://<?php echo $val['domain_name']?>"><i class="fa fa-arrow-right"></i>&nbsp;<?php echo ucfirst($val['domain_name'])?></a></li>
						<?php endforeach;?>	
					</ul>
					<div class="clearfix"></div>
				</div>
				<div class="col-md-12" style="text-align:center;"><a href="http://www.contrib.com/verticals/news/<?php echo $related_domains[0]['slug']?>" target="_blank" class="btn btn-success">View More</a></div>
			</div>
		</div>
		<?php endif;?>
	</div>
</div>
<!-- <div class="wrap-referralprogram-container">
	<div class="container">
		<div class="row">
			<div class="col-md-12 text-center lead-ttle-top">
				<h1 class="brdr-lead">
					Referral Programs
				</h1>
			</div>
		</div>
		<div class="row item-container-rp">
		<?php if (count($programs)>0):?>
		        	<?php foreach ($programs as $key=>$val):?>
						<div class="col-md-4 col-sm-4 col-xs-12 item-selector">
							<div class="wrap-rp-bx-container text-center">
								 <?php echo $val['code']?>
							</div>
						</div>
				<?php endforeach;?>
		 <?php endif?>	
			
		</div>
	</div>
</div> -->

 <div class="wrap-referralprogram-container">
	<div class="container">
				<div class="row">
					<div class="col-md-12 text-center">
						<h1 class="ttle">Follow Linked.com and other great ventures <br> on the Contrib platform. </h1>
						<br><br>
					</div>
					<div class="col-md-12">
						<div class="owl-carousel container-feature">
							<?php foreach ($featuredsite as $featuredsite) { ?>
								   <div class="wrap-marketplace-box-item">
                            <a class="wmbi-img-logo" href="http://<?php echo $featuredsite['domain_name']; ?>">
                                <?php if(!empty($featuredsite['logo'])):?>
									<img src="<?php echo $featuredsite['logo']; ?>" class="img-responsive" alt="<?php echo $featuredsite['domain_name']; ?>">
								<?php else: ?>
									<img src="https://d2qcctj8epnr7y.cloudfront.net/contrib/logo-contrib-brand2.png" class="img-responsive">
								<?php endif; ?>
                            </a>
                            <h3 class="marg-m-ttlTop text-capitalize wmbi-ttle ellipsis">
                                <?php echo $featuredsite['domain_name']; ?>
                            </h3>
                            <p class="p-marg-btm">
                                Join our exclusive community of like minded people
                            </p>
                            <p>
                                <a target="_blank" href="http://<?php echo $featuredsite['domain_name']; ?>"><?php echo $featuredsite['domain_name']; ?></a>
                            </p>
                            <ul class="list-inline ul-wmbi-zero">
                                <li>
                                    <a class="btn btn-success btn-lg" target="_blank" href="http://<?php echo $featuredsite['domain_name']; ?>">Visit</a>
                                </li>
                                <li>
                                    <a class="btn btn-success btn-lg" target="_blank" href="https://contrib.com/brand/details/<?php echo $featuredsite['domain_name']; ?>">Details</a>
                                </li>
                            </ul>
                        </div>
							<?php }?>		
						</div>
					</div>
				</div>
			</div>
</div> 
<div class="container-index-wrap">
<div>

<? include_once 'footer.php';?>

<script>

  $(document).ready(function() {

   var docHeight = $(window).height();
   var footerHeight = $('.footer-v1').height();
   var footerTop = $('.footer-v1').position().top + footerHeight;

   if (footerTop < docHeight) {
    $('.footer-v1').css('margin-top', 10+ (docHeight - footerTop) + 'px');
   }
  });
 </script>