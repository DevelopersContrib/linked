<?php
    $domain =   "linked.com";
    $domainid = "1740";
    $memberid = "7";
    $title = "Linked.com- Linking people, skills and opportunities";
    $logo =  "https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-linked4.png";
    $description = "Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Join us today!";
    $account_ga = "UA-29828968-34";
    $description = stripslashes(str_replace('\n','<br>',$description));
    $background_image = "http://d2qcctj8epnr7y.cloudfront.net/uploads/people_walking_on_street-wallpaper.jpg";
    $fb_page =  "";
    $twitter = "";
    $bottom_text  = "";
    $forsale = "0";
    $forsaledefault = "1";
	  $forsaletext = "This domain belongs to the Global Ventures network. We have interesting opportunities for work, sponsors and partnerships.";
    $footer_banner = "";
    $domain_affiliate_link = "http://referrals.contrib.com/idevaffiliate.php?id=11&url=http://www.contrib.com/signup/firststep?domain=linked.com";
    $additional_html = "PGJyIC8+CjxzY3JpcHQgYXN5bmMgc3JjPSIvL3BhZ2VhZDIuZ29vZ2xlc3luZGljYXRpb24uY29tL3BhZ2VhZC9qcy9hZHNieWdvb2dsZS5qcyI+PC9zY3JpcHQ+CjwhLS0gTW92aWVzIHNpZGViYXIgYm94IC0tPgo8aW5zIGNsYXNzPSJhZHNieWdvb2dsZSIKICAgICBzdHlsZT0iZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6MzAwcHg7aGVpZ2h0OjI1MHB4IgogICAgIGRhdGEtYWQtY2xpZW50PSJjYS1wdWItMDM5MDgyMTI2MTQ2NTQxNyIKICAgICBkYXRhLWFkLXNsb3Q9IjE2ODg4NTk1MDYiPjwvaW5zPgo8c2NyaXB0PgooYWRzYnlnb29nbGUgPSB3aW5kb3cuYWRzYnlnb29nbGUgfHwgW10pLnB1c2goe30pOwo8L3NjcmlwdD4KPGJyIC8+CjxzY3JpcHQgYXN5bmMgc3JjPSIvL3BhZ2VhZDIuZ29vZ2xlc3luZGljYXRpb24uY29tL3BhZ2VhZC9qcy9hZHNieWdvb2dsZS5qcyI+PC9zY3JpcHQ+CjwhLS0gTW92aWVzIHNpZGViYXIgYm94IC0tPgo8aW5zIGNsYXNzPSJhZHNieWdvb2dsZSIKICAgICBzdHlsZT0iZGlzcGxheTppbmxpbmUtYmxvY2s7d2lkdGg6MzAwcHg7aGVpZ2h0OjI1MHB4IgogICAgIGRhdGEtYWQtY2xpZW50PSJjYS1wdWItMDM5MDgyMTI2MTQ2NTQxNyIKICAgICBkYXRhLWFkLXNsb3Q9IjE2ODg4NTk1MDYiPjwvaW5zPgo8c2NyaXB0PgooYWRzYnlnb29nbGUgPSB3aW5kb3cuYWRzYnlnb29nbGUgfHwgW10pLnB1c2goe30pOwo8L3NjcmlwdD4K";
    $piwik_id = '4';
    $related_domains = array (
  0 => 
  array (
    'domain_name' => 'bankscores.com',
    'domain_id' => '20435',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Bankscores1.png',
    'title' => 'Bankscores.com',
    'slug' => 'business',
  ),
  1 => 
  array (
    'domain_name' => 'businessplancompetition.com',
    'domain_id' => '16017',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-businessplancompetition1.png',
    'title' => 'Businessplancompetition.com',
    'slug' => 'business',
  ),
  2 => 
  array (
    'domain_name' => 'sportschart.com',
    'domain_id' => '22278',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-sportschart1.png',
    'title' => 'Sportschart.com',
    'slug' => 'business',
  ),
  3 => 
  array (
    'domain_name' => 'equitytip.com',
    'domain_id' => '24454',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-EquityTip1.png',
    'title' => 'Equitytip.com',
    'slug' => 'business',
  ),
  4 => 
  array (
    'domain_name' => 'metrocredits.com',
    'domain_id' => '23629',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-MetroCredits1.png',
    'title' => 'Metrocredits.com',
    'slug' => 'business',
  ),
  5 => 
  array (
    'domain_name' => 'harvardconnection.com',
    'domain_id' => '16',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-harvardconnection1.png',
    'title' => 'Harvardconnection.com',
    'slug' => 'business',
  ),
  6 => 
  array (
    'domain_name' => 'arbpoint.com',
    'domain_id' => '17634',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-arbpoint1.png',
    'title' => 'Arbpoint.com',
    'slug' => 'business',
  ),
  7 => 
  array (
    'domain_name' => 'metamansion.com',
    'domain_id' => '23569',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-MetaMansion1.png',
    'title' => 'Metamansion.com',
    'slug' => 'business',
  ),
  8 => 
  array (
    'domain_name' => 'venturedraft.com',
    'domain_id' => '17455',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Venturedraft1.png',
    'title' => 'Venturedraft.com',
    'slug' => 'business',
  ),
  9 => 
  array (
    'domain_name' => 'citivank.com',
    'domain_id' => '5080',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-citivank1.png',
    'title' => 'Citivank.com',
    'slug' => 'business',
  ),
  10 => 
  array (
    'domain_name' => 'permitstream.com',
    'domain_id' => '16623',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-PermitStream1.png',
    'title' => 'Welcome to permitstream.com',
    'slug' => 'business',
  ),
  11 => 
  array (
    'domain_name' => 'builderkit.com',
    'domain_id' => '17564',
    'logo' => 'https://s3.amazonaws.com/assets.zipsite.net/images/2013/logo-BuilderKit-1.png',
    'title' => 'Builderkit.com',
    'slug' => 'business',
  ),
  12 => 
  array (
    'domain_name' => 'sheriffservices.com',
    'domain_id' => '754',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-sheriffservices.png',
    'title' => 'Welcome to sheriffservices.com',
    'slug' => 'business',
  ),
  13 => 
  array (
    'domain_name' => 'startups.com',
    'domain_id' => '21887',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-StartUps1.png',
    'title' => 'Startups.com',
    'slug' => 'business',
  ),
  14 => 
  array (
    'domain_name' => 'hubs.com',
    'domain_id' => '1248',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-hubs.png',
    'title' => 'Hubs.com',
    'slug' => 'business',
  ),
);
    $fund_campaigns = array (
  0 => 
  array (
    'post_title' => 'Acting.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/acting-com/',
    'post_name' => 'acting-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/acting.com_.png',
    'post_content' => 'Acting.com allows actors and people in the entertainment industry to put up their profile to get casting audition jobs and opportunities. It also allows companies in the Production industry to...',
  ),
  1 => 
  array (
    'post_title' => 'CodeChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => NULL,
    'campaign_author' => NULL,
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/codechallenge-com/',
    'post_name' => 'codechallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/codechallenge.png',
    'post_content' => '<h4>Join CodeChallenge.com</h4>
<h4><strong>Are you an entrepreneur or want to work for a great online business?</strong></h4>
*Select your niche.
*Get mentorship and access to premium online...',
  ),
  2 => 
  array (
    'post_title' => 'Cookboard.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Florida',
    'campaign_author' => 'Maai Florendo',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cookboard-com/',
    'post_name' => 'cookboard-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/11/logo-CookBoard-2.png',
    'post_content' => 'Your #1 Local Food Marketplace community! Join us as we launch it Dec 2014!

Where local chefs create cook boards for availability to the local foodie community\\n\\n

In depth...',
  ),
  3 => 
  array (
    'post_title' => 'CoWork.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/cowork-com-virtual-opportunities-to-do-amazing-things/',
    'post_name' => 'cowork-com-virtual-opportunities-to-do-amazing-things',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/02/4743596194.jpg',
    'post_content' => '<a href="http://www.cowork.com">Cowork.com</a>

CoWork.com is an online venture creation network that works with other like minded professionals building awesome companies, projects and...',
  ),
  4 => 
  array (
    'post_title' => 'iChallenge.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'CoWork',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/ichallenge-com/',
    'post_name' => 'ichallenge-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/3616845592.jpg',
    'post_content' => 'Ichallenge.com is a gamification challenge framework that allows you to join a challenge or sponsor a challenge without monetary involvement.

&nbsp;',
  ),
  5 => 
  array (
    'post_title' => 'iContent.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/icontent-com/',
    'post_name' => 'icontent-com',
    'logo' => 'http://ifund.com/wp-content/uploads/2014/03/icontent-logo.png',
    'post_content' => '<p>iContent is a xml application that connects all your content into an integrated and intelligent system that learns and earns while you focus on creating amazing audio, visual and contextual...',
  ),
  6 => 
  array (
    'post_title' => 'Linked.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, Florida',
    'campaign_author' => 'iContent, LLC',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/linked-com/',
    'post_name' => 'linked-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/03/Linked_com-linked_com.png',
    'post_content' => 'Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Be a part of Linked.com and get equity shares for your donations.

<img...',
  ),
  7 => 
  array (
    'post_title' => 'MBAChallenge',
    'campaign_goal' => '10000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/mbachallenge/',
    'post_name' => 'mbachallenge',
    'logo' => 'http://ifund.com/wp-content/uploads/2015/06/IMG_1404.jpg',
    'post_content' => 'MBAChallenge is a leading skills based business game created to challenge college educated people with street smart professionals.',
  ),
  8 => 
  array (
    'post_title' => 'Micro Markets',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/micro-markets/',
    'post_name' => 'micro-markets',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/01/micromarkets1.png',
    'post_content' => '<a href="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets.png"><img alt="logo-micromarkets" src="http://ifund.com/wp-content/uploads/edd/2014/01/logo-micromarkets-300x44.png"...',
  ),
  9 => 
  array (
    'post_title' => 'MusicChannel.com',
    'campaign_goal' => '100000.00',
    'campaign_location' => 'Delray Beach, FL',
    'campaign_author' => 'MBACHallenge',
    'campaign_type' => 'donation',
    'permalink' => 'http://ifund.com/campaigns/musicchannel-com/',
    'post_name' => 'musicchannel-com',
    'logo' => 'http://ifund.com/wp-content/uploads/edd/2014/07/51661884511.jpg',
    'post_content' => 'MusicChannel is a weekly bounty competition that allows unsigned artists to publish their songs, make them viral and if they are selected will win weekly bounties!

We are looking for backers...',
  ),
);
    $approved_partner = array (
  'success' => true,
  'data' => 
  array (
    0 => 
    array (
      'partner_id' => '54088',
      'summary' => 'Compwiz.com',
      'company_name' => 'Compwiz.com',
      'domain' => 'linked.com',
      'url' => 'http://compwiz.com',
      'approved_by' => '115',
      'date_applied' => '2016-04-04 06:22:02',
      'approved' => '1',
      'image' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-compwiz.png',
      'member_id' => '0',
      'approved_status' => 'approved',
      'slug' => NULL,
      'type' => NULL,
      'partner_views' => '0',
      'link_type' => 'link',
      'code' => NULL,
      'is_custom' => '0',
      'description' => 'Join our exclusive community of like minded people on compwiz.com',
      'exchange_url' => NULL,
      'ld_id' => '0',
      'ld_url' => NULL,
      'in_equity' => '0',
    ),
    1 => 
    array (
      'partner_id' => '36730',
      'summary' => 'Contribute your Skills, Services, Apps, Contacts or Capital, part-time. Help a team of other passionate people doing amazing things. Come learn and earn! Amazing things happen with the right people, technology, business model, resources and passion. Earn equity ownership, Learn from other great people, Lead a venture and distribute up to 2% of the shares to your charity.',
      'company_name' => 'Contrib.com',
      'domain' => 'linked.com',
      'url' => 'http://www.contrib.com',
      'approved_by' => '10',
      'date_applied' => '2014-11-04 06:44:04',
      'approved' => '1',
      'image' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-contrib-174x35.png',
      'member_id' => '7',
      'approved_status' => 'approved',
      'slug' => 'contrib-linked-com',
      'type' => 'Added Value Marketing Partnerships',
      'partner_views' => '0',
      'link_type' => 'link',
      'code' => NULL,
      'is_custom' => '0',
      'description' => 'We are a community of Entrepreneurs, Developers, Designers, Marketers and Specialists from around the world building, managing and monetizing virtual businesses on premium domains for equity and cash grants.',
      'exchange_url' => NULL,
      'ld_id' => '0',
      'ld_url' => NULL,
      'in_equity' => '0',
    ),
    2 => 
    array (
      'partner_id' => '531',
      'summary' => 'eQuality IT Solutions LLC is a family owned and operated company founded by technology\\nprofessionals with a combined 30 years of experience. We specialize in providing Microsoft Cloud and Business Intelligence based technology solutions & services.\\n\\nOur mission is to connect small and medium businesses with powerful local and cloud-driven and mobile Business Intelligence tools and business productivity training that are available to leverage opportunities at a price companies can afford. We provide free training tip and resources also on our \\"Bee I\\" For everyone blog and do affiliate marketing there and through social meeting channels with it and promote our current partners: Microsoft Store, Lynda, Best Buy, Pinnacle and more. We also provide business and professionals guidance via our postings on training, improving business insight and certification guidance. On our owned and privately sponsored non-profit site @WomenInGrace.org our mission is to provide our no cost elected participants mentoring on technology, career guidance to make them more marketable and serve veterans with resources to from our partners and have a volunteer team on our women in grace organization supporters group from all types of professionals in a diverse channel of businesses. Please visit our sites mentioned above along with our main site @ eQualityITsolutions.com to see what we are all about. If you have any questions please feel free in contacting me and I would be happy to chat. We would love to be part of your exciting endeavor and hope we can partner up soon :) thanks very much for your review .... Tone\\\' ...  Ps my LinkedIn profile is under Tone\\\' Shelby or quick link http://linkedin/in/toneshelbyn\\n\\nLet us help you find your clients new sources of productivity, revenue, identify cost cutting opportunities and improve financial visibility.\\n\\n',
      'company_name' => 'eQualityITsolutions LLC',
      'domain' => 'linked.com',
      'url' => 'http://eQualityITsolutions.com',
      'approved_by' => '12',
      'date_applied' => '2014-07-31 04:05:44',
      'approved' => '1',
      'image' => NULL,
      'member_id' => '32591',
      'approved_status' => 'approved',
      'slug' => 'equalityitsolutions-llc',
      'type' => 'Added Value Marketing Partnerships',
      'partner_views' => '0',
      'link_type' => 'link',
      'code' => NULL,
      'is_custom' => '0',
      'description' => NULL,
      'exchange_url' => NULL,
      'ld_id' => '0',
      'ld_url' => NULL,
      'in_equity' => '0',
    ),
    3 => 
    array (
      'partner_id' => '12769',
      'summary' => 'Global Ventures owns a premium network of 20,000 websites and powerful tools to help you build successful companies quickly. Some of the things we offer you include a great domain name with targeted traffic, unique business model, equity ownership, and flexible, performance based compensation. You just need to bring your knowledge, passion and work smart.',
      'company_name' => 'GlobalVentures.com',
      'domain' => 'linked.com',
      'url' => 'http://globalventures.com',
      'approved_by' => '10',
      'date_applied' => '2014-11-04 01:34:01',
      'approved' => '1',
      'image' => 'https://d2qcctj8epnr7y.cloudfront.net/images/lucille/logo-gv-re283x35.png',
      'member_id' => '7',
      'approved_status' => 'approved',
      'slug' => 'globalventures-linked-com',
      'type' => 'Added Value Marketing Partnerships',
      'partner_views' => '0',
      'link_type' => 'link',
      'code' => NULL,
      'is_custom' => '0',
      'description' => 'With over 17 years of internet experience, we built a network of over 20,000 websites and created dozens of successful businesses. We would love to work on the next cutting-edge projects with great companies and talented people.',
      'exchange_url' => NULL,
      'ld_id' => '0',
      'ld_url' => NULL,
      'in_equity' => '1',
    ),
    4 => 
    array (
      'partner_id' => '51506',
      'summary' => 'The International Business Council (IBC) is a business association, established in August 1965, created in New York City, New York, whose membership includes a wide range of local and international businesses who have created thousands of jobs and have a combined investment of over one billion USD in the United States of America economy. \\n\\nAs well as promoting the common interests of business investors and providing members with relevant information and advice to support their business operations, IBC’s mission is to make the United States of America a more attractive investment location by promoting good business legislation and efficient business practices, working in partnership with the government of the United States of America and other local and foreign organizations. IBC actively supports the economic reform process and ensures that private sector investors are represented in Government policy activities. IBC also has strong recognition amongst the International Finance Institutions, Embassies, and Donor Agencies as a key player in the process of reform. \\n\\nIBC supports the ten principles of the UN Global Compact, setting core values in the areas of human rights, labour standards, environment and anti-corruption. IBC encourages members to embrace, support and enact these principles within their sphere of influence. \\n\\nIBC works cooperatively with government and other local and international organizations to fight against corruption and to change laws and practice that impede social or economic justice\\n',
      'company_name' => 'International Business Council',
      'domain' => 'linked.com',
      'url' => 'https://www.facebook.com/International-Business-Council-419479594923476/?view_public_for=419479594923476',
      'approved_by' => '115',
      'date_applied' => '2015-12-15 09:06:54',
      'approved' => '1',
      'image' => NULL,
      'member_id' => '68650',
      'approved_status' => 'approved',
      'slug' => 'international-business-council',
      'type' => 'Added Value Marketing Partnerships',
      'partner_views' => '0',
      'link_type' => 'link',
      'code' => NULL,
      'is_custom' => '0',
      'description' => NULL,
      'exchange_url' => NULL,
      'ld_id' => '0',
      'ld_url' => NULL,
      'in_equity' => '0',
    ),
  ),
);
    $programs = array (
  0 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=11_4_1_32" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/handyman-badge-11.png" width="170" height="200" alt="handyman badge 11" title="handyman badge 11"></a>',
    'title' => 'Handyman',
  ),
  1 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=11_17_1_52" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/handyman-needed-2.jpg" width="231" height="110" alt="Refer Homeowners" title="Refer Homeowners"></a>',
    'title' => 'Handyman Homeowners',
  ),
  4 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=11_5_1_36" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-socialId-728x90-1.png" width="728" height="90" alt="Social Id Banners" title="Social Id Banners"></a>',
    'title' => 'SocialId',
  ),
  5 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=11_1_1_3" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/badge-contrib-2.png" width="150" height="150" alt="Proud Member of Contrib" title="Proud Member of Contrib"></a>',
    'title' => 'Contrib',
  ),
  6 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=11_15_1_50" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/talentdirect-logo.jpg" width="243" height="131" alt="Become a Talent" title="Become a Talent"></a>',
    'title' => 'Talentdirect',
  ),
  7 => 
  array (
    'code' => '<a href="http://referrals.contrib.com/idevaffiliate.php?id=11_6_1_37" target="_blank"><img style="border:0px" src="http://referrals.contrib.com/banners/ban-virtualinterns-728x90-1.png" width="728" height="90" alt="" title=""></a>',
    'title' => 'VirtualInterns',
  ),
);

    $featuredsite = array (
  0 => 
  array (
    'domain_name' => 'attorneyforum.com',
    'logo' => '',
    'description' => 'Join our exclusive community of like minded people on attorneyforum.com',
    'title' => 'Welcome to attorneyforum.com',
  ),
  1 => 
  array (
    'domain_name' => 'eurodesign.com',
    'logo' => 'https://s3.amazonaws.com/assets.zipsite.net/images/2013/logo-EuroDesign-light.png',
    'description' => 'Join our Design Challenges on Euro Design!',
    'title' => 'Welcome to Euro Design',
  ),
  2 => 
  array (
    'domain_name' => 'agentnews.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-agentnews.png',
    'description' => 'Join our exclusive community of like minded people on agentnews.com',
    'title' => 'Welcome to agentnews.com - Get the freshest news on Agent News',
  ),
  3 => 
  array (
    'domain_name' => 'mychallenge.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-mychallenge5.png',
    'description' => 'Join our exclusive community of like minded people on mychallenge.com',
    'title' => 'Mychallenge.com',
  ),
  4 => 
  array (
    'domain_name' => 'ibot.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-IBot.png',
    'description' => 'Welcome to ibot.com - Join and Build your own Bots',
    'title' => 'Welcome to our Bot community ibot.com. Join us and build your own bots',
  ),
  5 => 
  array (
    'domain_name' => 'consultants.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-consultants1.png',
    'description' => 'Join our exclusive community of like minded people on consultants.com',
    'title' => 'Consultants',
  ),
  6 => 
  array (
    'domain_name' => 'linked.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-linked4.png',
    'description' => 'Linking people, skills and opportunities to create the worlds largest crowd commerce business creation system. Join us today!',
    'title' => 'Linked.com- Linking people, skills and opportunities',
  ),
  7 => 
  array (
    'domain_name' => 'photostream.com',
    'logo' => 'https://assets.zipsite.net.s3.amazonaws.com/images/marvinpogi/logo-photostream2.png',
    'description' => 'Have a funny or unique Photo taken from your SmartPhone? Register Now for free to Win amazing Prizes in our 2013 PhotoChallenge, Sponsored by PhotoStream. Submit photos to win challenges today!',
    'title' => 'PhotoStream - Join Photo Stream and Submit photos to win Photo Stream challenges! ',
  ),
  8 => 
  array (
    'domain_name' => 'cowork.com',
    'logo' => 'https://s3.amazonaws.com/assets.zipsite.net/images/2013/logo-cowork-2.png',
    'description' => 'Come Learn and Earn with other great professionals on leading Internet Ventures.  Take 1 hr, 1 day, 1 week and earn amazing equity ownership based around results you deliver.',
    'title' => 'Cowork.com',
  ),
  9 => 
  array (
    'domain_name' => 'abot.com',
    'logo' => '',
    'description' => 'Welcome to abot.com - Join and Build your own Bots',
    'title' => 'Welcome to our Bot community abot.com. Join us and build your own bots',
  ),
  10 => 
  array (
    'domain_name' => 'green.org',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Green1.png',
    'description' => 'Get to know the finest Eco enthusiasts. Find tips and editorial coverage of green living enterprises as well as the Eco-friendly products. Get inspired with green habits, green living,  nature  and more. Sign up now at Green.org',
    'title' => 'Green.org',
  ),
  11 => 
  array (
    'domain_name' => 'javapoints.com',
    'logo' => '',
    'description' => 'Join our exclusive community of like minded people on javapoints.com',
    'title' => 'Javapoints.com',
  ),
  12 => 
  array (
    'domain_name' => 'veteransrehab.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-VeteransRehab-1.png',
    'description' => 'Getting results through personalization and utilization of Technology, Dietary and Education program for todays Veterans.  Can you help?  Join today and Support a Veteran.',
    'title' => 'Welcome to veteransrehab.com',
  ),
  13 => 
  array (
    'domain_name' => 'staffing.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-staffing1.png',
    'description' => 'Get your Part Time Job at Staffing.com! Contribute to Premium Brands Today! Join our staffing opportunities today.',
    'title' => 'Staffing.com - Learn more about Joining our Partner Network',
  ),
  14 => 
  array (
    'domain_name' => 'globalventures.com',
    'logo' => 'https://contrib.com/uploads/logo/image_logo-gventures10-420x60.png',
    'description' => 'Global Ventures, LLC, established in 1996, is a Real Estate and Technology company focused on building and leveraging electronic corporations (eCorp) within the Domain Name System.  Premium domains and companies such as Referrals.com,Staffing.com, Mergers.com, Domain Holdings, VentureCamp, Handyman.com, DSL.com and over 20,000 others are the core digital asset and building blocks of Global Ventures.',
    'title' => 'Globalventures.com',
  ),
  15 => 
  array (
    'domain_name' => 'cookboard.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-CookBoard-2.png',
    'description' => 'We are launching CookBoard.com Your #1 Local Food Marketplace community! Join us as we launch it Dec 2014!',
    'title' => 'Cookboard.com Your #1 Local Food Marketplace',
  ),
  16 => 
  array (
    'domain_name' => 'virtualinterns.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-virtualinterns3.png',
    'description' => 'Join our exclusive community of like minded people on virtualinterns.com',
    'title' => 'Virtual Interns',
  ),
  17 => 
  array (
    'domain_name' => 'dailymed.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-DailyMed1.png',
    'description' => 'Join our exclusive community of like minded people on dailymed.com',
    'title' => 'Welcome to dailymed.com',
  ),
  18 => 
  array (
    'domain_name' => 'appcast.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-appcast1.png',
    'description' => 'Join our exclusive community of like minded people on appcast.com',
    'title' => 'Welcome to appcast.com',
  ),
  19 => 
  array (
    'domain_name' => 'codechallenge.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-codechallenge.png',
    'description' => 'CodeChallenge allows coders sets of challenges that they could use to get equity options to any our premium assets.',
    'title' => 'Codechallenge.com',
  ),
  20 => 
  array (
    'domain_name' => 'mbachallenge.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-MbaChallenge1.png',
    'description' => 'Join our exclusive community of like minded people on mbachallenge.com',
    'title' => 'Welcome to mbachallenge.com',
  ),
  21 => 
  array (
    'domain_name' => 'automations.com',
    'logo' => '',
    'description' => 'Join our exclusive community of like minded people on automations.com',
    'title' => 'Welcome to automations.com',
  ),
  22 => 
  array (
    'domain_name' => 'modeltable.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-modeltable-6.png',
    'description' => 'Models helping set The Vibe for your Venue. Book your table now.',
    'title' => 'Welcome to ModelTable.com',
  ),
  23 => 
  array (
    'domain_name' => 'channeltv.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-ChannelTv.png',
    'description' => 'Join our exclusive community of like minded people on channeltv.com. Join the discussion on TV series, Movies and TV stars.',
    'title' => 'Channel TV - ChannelTv.com - Join our community today',
  ),
  24 => 
  array (
    'domain_name' => 'venturechallenge.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-venturechallenge.png',
    'description' => 'Join our exclusive community of like minded people on venturechallenge.com',
    'title' => 'Welcome to venturechallenge.com',
  ),
  25 => 
  array (
    'domain_name' => 'wind.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-wind1.png',
    'description' => 'Wind and weather forecasts for sailors, windsurfers, kite surfers, surfers and other wind related activities.  Find instantly  the wind forecast for your location.  High resolution weather and wind model for hourly forecast.',
    'title' => 'Wind.com',
  ),
  26 => 
  array (
    'domain_name' => 'weed.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Weed1.png',
    'description' => ' Join the leading network shaped around the Cannabis industry.  Learn, Earn and Contribute with other amazing people.',
    'title' => 'Weed.com',
  ),
  27 => 
  array (
    'domain_name' => 'tornachilles.com',
    'logo' => '',
    'description' => 'Join our exclusive community of like minded people on tornachilles.com',
    'title' => 'Get Treatments and Advice for Achilles Tendon Pain',
  ),
  28 => 
  array (
    'domain_name' => 'applications.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Applications-7.png',
    'description' => 'The #1 Application Brand Matching Marketplace. List your applications from different marketplaces and get revenue for every install.',
    'title' => 'Applications.com',
  ),
  29 => 
  array (
    'domain_name' => 'uniforms.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-Uniforms1.png',
    'description' => 'Best selection of scrubs, nursing uniforms, care professionals, doctors and more. Uniforms.com  offers a wide selaction of professional uniforms and  features some of the most in demand medical apparel that  fit to your needs. Sign up today to have an exclusive  online uniform catalog sent to you. ',
    'title' => 'Uniforms.com',
  ),
  30 => 
  array (
    'domain_name' => 'educorp.com',
    'logo' => 'https://vnoc-domain-files.s3.amazonaws.com/file1461891739_edulogo.png',
    'description' => 'educorp.com helps you in your educational processes, projects and assignments.',
    'title' => 'educorp.com helps you in your educational processes, projects and assignments.',
  ),
  31 => 
  array (
    'domain_name' => 'nanotechnology.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/2013/logo-NanoTechnology1.png',
    'description' => 'Join our exclusive community of like minded people on nanotechnology.com',
    'title' => 'nanotechnology.com Welcome to nanotechnology.com -We\\\'re a part of the Tecnical Vertical',
  ),
  32 => 
  array (
    'domain_name' => 'handyman.com',
    'logo' => 'https://d2qcctj8epnr7y.cloudfront.net/images/marvinpogi/logo-handyman.png',
    'description' => 'Join our exclusive community of like minded people on handyman.com',
    'title' => 'Handyman',
  ),
  33 => 
  array (
    'domain_name' => 'appcentre.com',
    'logo' => 'https://contrib.com/uploads/logo/appcentre.png',
    'description' => 'Join our exclusive community of like minded people on appcentre.com. Contribute and learn how to Create apps ',
    'title' => 'Welcome to appcentre.com',
  ),
  34 => 
  array (
    'domain_name' => 'hackersrank.com',
    'logo' => '',
    'description' => 'Join our hackersrank.com community and help build great apps on world class premium domains',
    'title' => 'Welcome to hackersrank.com - Join our Developer Community Today and build Great apps on World class domains',
  ),
);

	
?>